/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.MediFam.DAL;

import java.sql.*;

/**
 *
 * @author emily
 */
public class ModuloConexao {
    //método responsavel por estabelecer a conexao com o banco 
    public static Connection conector() {
        Connection conexao = null;
        // a linha abaixo "cham" o Driver
        String driver = "com.mysql.cj.jdbc.Driver";
        // Armazenando informações referente ao banco 
        String url = "jdbc:mysql://localhost:3306/medifam";
        String user = "root";
        String password = "38242526";
        // Estabelecendo aa conexão com o banco 
        try {
            Class.forName(driver);
            conexao = DriverManager.getConnection(url, user, password);
            return conexao;
        } catch (Exception e) {
            //a linha abaixo serve de apoio para esclarecer o erro 
            //System.out.println(e);
            return null;
        }
        
    }
    
}
